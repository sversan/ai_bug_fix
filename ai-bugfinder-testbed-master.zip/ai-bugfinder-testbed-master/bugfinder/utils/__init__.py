""" Utilities for bugfinder
"""
