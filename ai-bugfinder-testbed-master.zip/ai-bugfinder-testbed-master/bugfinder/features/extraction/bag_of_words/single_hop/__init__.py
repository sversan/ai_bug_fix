""" Single hop extractors
"""
