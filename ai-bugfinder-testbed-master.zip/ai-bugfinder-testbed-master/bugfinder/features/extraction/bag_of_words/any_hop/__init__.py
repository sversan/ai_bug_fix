""" Any hop extractors
"""
