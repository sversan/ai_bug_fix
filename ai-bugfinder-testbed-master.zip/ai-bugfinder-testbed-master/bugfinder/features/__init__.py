""" Module for extracting features for training purposes.
"""
