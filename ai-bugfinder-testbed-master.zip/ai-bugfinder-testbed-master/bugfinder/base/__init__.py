""" Base classes for dataset instantiation and processing.
"""
