bugfinder.models.dnn_classifier
===============================

.. automodule:: bugfinder.models.dnn_classifier
    :members:
    :undoc-members:
    :show-inheritance:
