bugfinder.models.linear_classifier
==================================

.. automodule:: bugfinder.models.linear_classifier
    :members:
    :undoc-members:
    :show-inheritance:
