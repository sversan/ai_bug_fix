bugfinder.models
================

.. automodule:: bugfinder.models
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::
        :maxdepth: 2

    linear_classifier
    lstm_classifier
    interproc_lstm
    blstm_classifier
    sequential
    dnn_classifier
