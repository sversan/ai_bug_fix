bugfinder.models.sequential
===========================

.. automodule:: bugfinder.models.sequential
    :members:
    :undoc-members:
    :show-inheritance:
