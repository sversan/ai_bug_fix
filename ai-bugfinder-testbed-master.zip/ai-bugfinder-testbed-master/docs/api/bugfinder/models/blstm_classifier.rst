bugfinder.models.blstm_classifier
=================================

.. automodule:: bugfinder.models.blstm_classifier
    :members:
    :undoc-members:
    :show-inheritance:
