bugfinder.models.interproc_lstm
===============================

.. automodule:: bugfinder.models.interproc_lstm
    :members:
    :undoc-members:
    :show-inheritance:
