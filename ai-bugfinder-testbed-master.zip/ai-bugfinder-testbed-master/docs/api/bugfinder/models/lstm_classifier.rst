bugfinder.models.lstm_classifier
================================

.. automodule:: bugfinder.models.lstm_classifier
    :members:
    :undoc-members:
    :show-inheritance:
