bugfinder.utils.rand
====================

.. automodule:: bugfinder.utils.rand
    :members:
    :undoc-members:
    :show-inheritance:
