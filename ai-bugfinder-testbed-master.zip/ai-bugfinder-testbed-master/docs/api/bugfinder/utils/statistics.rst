bugfinder.utils.statistics
==========================

.. automodule:: bugfinder.utils.statistics
    :members:
    :undoc-members:
    :show-inheritance:
