bugfinder.utils.progressbar
===========================

.. automodule:: bugfinder.utils.progressbar
    :members:
    :undoc-members:
    :show-inheritance:
