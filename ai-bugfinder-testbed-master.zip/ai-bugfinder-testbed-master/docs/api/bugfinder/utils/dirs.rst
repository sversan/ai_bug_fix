bugfinder.utils.dirs
====================

.. automodule:: bugfinder.utils.dirs
    :members:
    :undoc-members:
    :show-inheritance:
