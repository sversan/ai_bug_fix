bugfinder.features.reduction.sequential_feature_selector
========================================================

.. automodule:: bugfinder.features.reduction.sequential_feature_selector
    :members:
    :undoc-members:
    :show-inheritance:
