bugfinder.features.reduction
============================

.. automodule:: bugfinder.features.reduction
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::
        :maxdepth: 2

    pca
    recursive_feature_elimination
    auto_encoder
    select_from_model
    univariate_select
    variance_threshold
    sequential_feature_selector
