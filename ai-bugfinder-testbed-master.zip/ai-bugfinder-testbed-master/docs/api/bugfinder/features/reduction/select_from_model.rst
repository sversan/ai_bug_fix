bugfinder.features.reduction.select_from_model
==============================================

.. automodule:: bugfinder.features.reduction.select_from_model
    :members:
    :undoc-members:
    :show-inheritance:
