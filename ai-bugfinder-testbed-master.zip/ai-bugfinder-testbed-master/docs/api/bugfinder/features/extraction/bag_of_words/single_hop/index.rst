bugfinder.features.extraction.bag_of_words.single_hop
=====================================================

.. automodule:: bugfinder.features.extraction.bag_of_words.single_hop
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::
        :maxdepth: 2

    raw
