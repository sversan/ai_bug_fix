bugfinder.features.extraction.bag_of_words.hops_n_flows
=======================================================

.. automodule:: bugfinder.features.extraction.bag_of_words.hops_n_flows
    :members:
    :undoc-members:
    :show-inheritance:
