bugfinder.features.extraction.word2vec.embeddings
=================================================

.. automodule:: bugfinder.features.extraction.word2vec.embeddings
    :members:
    :undoc-members:
    :show-inheritance:
