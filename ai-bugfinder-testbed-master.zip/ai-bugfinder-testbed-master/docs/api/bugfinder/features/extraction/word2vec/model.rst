bugfinder.features.extraction.word2vec.model
============================================

.. automodule:: bugfinder.features.extraction.word2vec.model
    :members:
    :undoc-members:
    :show-inheritance:
