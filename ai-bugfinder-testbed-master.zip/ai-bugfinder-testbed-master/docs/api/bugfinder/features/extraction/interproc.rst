bugfinder.features.extraction.interproc
=======================================

.. automodule:: bugfinder.features.extraction.interproc
    :members:
    :undoc-members:
    :show-inheritance:
