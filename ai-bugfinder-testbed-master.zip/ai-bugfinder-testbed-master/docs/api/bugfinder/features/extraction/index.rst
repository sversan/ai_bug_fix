bugfinder.features.extraction
=============================

.. automodule:: bugfinder.features.extraction
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::
        :maxdepth: 2

    interproc
    bag_of_words/index
    word2vec/index
    node2vec/index
