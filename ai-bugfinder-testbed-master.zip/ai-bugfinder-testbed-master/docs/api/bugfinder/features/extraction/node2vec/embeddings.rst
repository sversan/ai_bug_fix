bugfinder.features.extraction.node2vec.embeddings
=================================================

.. automodule:: bugfinder.features.extraction.node2vec.embeddings
    :members:
    :undoc-members:
    :show-inheritance:
