bugfinder.features.extraction.node2vec
======================================

.. automodule:: bugfinder.features.extraction.node2vec
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::
        :maxdepth: 2

    embeddings
    model
    implementation
