bugfinder.features.extraction.node2vec.model
============================================

.. automodule:: bugfinder.features.extraction.node2vec.model
    :members:
    :undoc-members:
    :show-inheritance:
