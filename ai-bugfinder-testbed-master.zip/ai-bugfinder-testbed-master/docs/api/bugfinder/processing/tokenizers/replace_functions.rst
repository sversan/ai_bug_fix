bugfinder.processing.tokenizers.replace_functions
=================================================

.. automodule:: bugfinder.processing.tokenizers.replace_functions
    :members:
    :undoc-members:
    :show-inheritance:
