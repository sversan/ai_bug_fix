bugfinder.processing.tokenizers.replace_variables
=================================================

.. automodule:: bugfinder.processing.tokenizers.replace_variables
    :members:
    :undoc-members:
    :show-inheritance:
