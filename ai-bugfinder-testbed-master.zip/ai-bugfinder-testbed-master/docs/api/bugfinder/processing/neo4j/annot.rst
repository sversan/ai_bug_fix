bugfinder.processing.neo4j.annot
================================

.. automodule:: bugfinder.processing.neo4j.annot
    :members:
    :undoc-members:
    :show-inheritance:
