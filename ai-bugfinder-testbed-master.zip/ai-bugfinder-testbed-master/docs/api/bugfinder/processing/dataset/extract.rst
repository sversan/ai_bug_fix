bugfinder.processing.dataset.extract
====================================

.. automodule:: bugfinder.processing.dataset.extract
    :members:
    :undoc-members:
    :show-inheritance:
