bugfinder.processing.dataset.fix_rights
=======================================

.. automodule:: bugfinder.processing.dataset.fix_rights
    :members:
    :undoc-members:
    :show-inheritance:
