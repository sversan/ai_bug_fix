bugfinder.processing.dataset
============================

.. automodule:: bugfinder.processing.dataset
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::
    :maxdepth: 2

    inverse
    copy
    fix_rights
    extract
