bugfinder.processing.sink_tagging
=================================

.. automodule:: bugfinder.processing.sink_tagging
    :members:
    :undoc-members:
    :show-inheritance:
