bugfinder.processing.cleaning.remove_comments
=============================================

.. automodule:: bugfinder.processing.cleaning.remove_comments
    :members:
    :undoc-members:
    :show-inheritance:
