bugfinder.processing.cleaning.remove_interproc_files
====================================================

.. automodule:: bugfinder.processing.cleaning.remove_interproc_files
    :members:
    :undoc-members:
    :show-inheritance:
