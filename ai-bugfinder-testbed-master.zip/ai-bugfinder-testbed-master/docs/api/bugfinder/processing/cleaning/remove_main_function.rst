bugfinder.processing.cleaning.remove_main_function
==================================================

.. automodule:: bugfinder.processing.cleaning.remove_main_function
    :members:
    :undoc-members:
    :show-inheritance:
