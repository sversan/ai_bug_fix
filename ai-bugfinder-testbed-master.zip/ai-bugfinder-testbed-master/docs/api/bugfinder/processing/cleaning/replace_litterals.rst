bugfinder.processing.cleaning.replace_litterals
===============================================

.. automodule:: bugfinder.processing.cleaning.replace_litterals
    :members:
    :undoc-members:
    :show-inheritance:
