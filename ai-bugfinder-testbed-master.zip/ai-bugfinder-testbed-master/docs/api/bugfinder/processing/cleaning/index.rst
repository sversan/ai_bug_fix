bugfinder.processing.cleaning
=============================

.. automodule:: bugfinder.processing.cleaning
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::
        :maxdepth: 2

    replace_litterals
    remove_cpp_files
    remove_main_function
    remove_interproc_files
    remove_comments
