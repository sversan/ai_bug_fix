bugfinder.processing.cleaning.remove_cpp_files
==============================================

.. automodule:: bugfinder.processing.cleaning.remove_cpp_files
    :members:
    :undoc-members:
    :show-inheritance:
