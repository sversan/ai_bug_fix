bugfinder.settings
==================

.. automodule:: bugfinder.settings
    :members:
    :undoc-members:
    :show-inheritance:
