.. include:: readme.rst

.. toctree::
    :hidden:
    :maxdepth: 2

    readme
    pipelines
    processing
    examples/index
    api/index
