""" Tests for bugfinder utilities
"""
