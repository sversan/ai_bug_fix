class MockEstimator:
    def fit(self, input_features, input_results):
        return self
